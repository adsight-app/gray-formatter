from __future__ import annotations

from gray_formatter._main import main

if __name__ == '__main__':
    raise SystemExit(main())
