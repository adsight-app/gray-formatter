# Gray formatter

Black formatter with some customizations.